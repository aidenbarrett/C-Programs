#include <stdio.h>
#include <stdlib.h>

#define sz 20

int main()
{
    char first_name[sz];
    char surname[sz];
    char name[sz];

    printf("Please enter your Firstname: ");
    scanf("%s",&first_name[sz]);

    printf("Please enter your Surname: ");
    scanf("%s",&surname[sz]);



    printf("Your Firstname is %d characters long", &);


    printf("Your Surname is %d characters long", &);


    printf("Your Name is:", &name[sz]);

    return 0;
}
