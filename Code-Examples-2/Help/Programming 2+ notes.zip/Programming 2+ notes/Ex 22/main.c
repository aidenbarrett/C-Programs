#include <stdio.h>
#include <stdlib.h>


//function prototype
void hello(void);

int main(void)
{
    //function call
    hello();

    return 0;
}

//function definition
void hello(void)
{
    printf("Hello world!\n");

    return;
}



