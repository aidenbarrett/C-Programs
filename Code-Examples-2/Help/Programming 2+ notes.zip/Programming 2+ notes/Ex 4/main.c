#include <stdio.h>
#include <stdlib.h>

int main()
{

    char namespace[10];

    printf("Please input your name: ");
    scanf("%s", &namespace);

    printf("\n\nYour name is %s!!\n", namespace);

    return 0;
}
