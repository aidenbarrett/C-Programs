#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;

    printf("Please input a Number: ");
    scanf("%d", &x);

    printf("\nThe number you inputted was: %d\n", x);

    return 0;
}
